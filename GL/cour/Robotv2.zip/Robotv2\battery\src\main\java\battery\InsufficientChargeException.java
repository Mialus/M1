package battery;

public class InsufficientChargeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7068684380888005700L;
}
