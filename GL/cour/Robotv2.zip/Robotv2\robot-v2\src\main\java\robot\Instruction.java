package robot;


public enum Instruction {
    TURNLEFT,
    BACKWARD,
    TURNRIGHT,
    FORWARD
}
