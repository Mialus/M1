package robot;

public enum Direction {
    NORTH, WEST, SOUTH, EAST
}
