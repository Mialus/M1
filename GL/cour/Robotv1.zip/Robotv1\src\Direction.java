/**
 * Created with IntelliJ IDEA.
 * User: fabrice
 * Date: 30/08/13
 * Time: 11:37
 * To change this template use File | Settings | File Templates.
 */
public enum Direction {
    NORTH, WEST, SOUTH, EAST
}
