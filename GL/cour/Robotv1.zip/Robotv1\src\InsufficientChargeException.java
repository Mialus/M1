public class InsufficientChargeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8864450321354901913L;
}
