public enum Instruction {
    TURNLEFT,
    BACKWARD,
    TURNRIGHT,
    FORWARD
}
