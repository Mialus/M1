//Wargnier Pierre

package genetic;

public class GA {
final static int POP=50;
final static int GEN=20;
    public static void main(String[] args) {
    	int a,b,c;
        // Set a candidate solution
       // FitnessCalc.setSolution("000000000001100100");

        // Create an initial population
        Population myPop = new Population(POP, true);
        // Evolve our population until we reach an optimum solution
        int generationCount = 0;
        while (generationCount<GEN) {
        	for(int i = 0; i<POP;i++){
        	System.out.println("a : " + myPop.getIndividual(i).getA() + " b : " + myPop.getIndividual(i).getB()+ " c : " + myPop.getIndividual(i).getC());
        	}
            generationCount++;
            System.out.println("Generation: " + generationCount + " FittestIndividu: " + myPop.getFittest().getFitness() + " FitnessPopulation: " + myPop.getFitnessPop());
            myPop = Algorithm.evolvePopulation(myPop);
        }
        System.out.println("Solution found!");
        System.out.println("Generation: " + generationCount);
        System.out.println("Genes:");
        a = myPop.getFittest().getA();
        b = myPop.getFittest().getB();
        c = myPop.getFittest().getC();
        System.out.println(" a :" + a + " b : "+b+" c: "+c);

    }
}

//myPop.getFittest().getFitness() < FitnessCalc.getMaxFitness()