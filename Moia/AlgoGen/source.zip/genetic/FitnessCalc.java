//Wargnier Pierre

package genetic;

public class FitnessCalc {

    // Calculate inidividuals fittness by comparing it to our candidate solution
    static int getFitness(Individual individual) {
        int fitness = 0;
        fitness = individual.getB();
        return fitness;
    }
}


/*int i = 0; i < individual.size() && i < solution.length; i++
individual.getGene(i) == solution[i]*/