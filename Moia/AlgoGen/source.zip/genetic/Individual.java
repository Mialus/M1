//Wargnier Pierre

package genetic;

public class Individual {

    static int defaultGeneLength = 20;
    private byte[] genes = new byte[defaultGeneLength];
    // Cache
    private int fitness = 0;
    private int a,b,c,i;
    private double pourcen;

    // Create a random individual
    public void generateIndividual() {
        for (i = 0; i < size(); i++) {
            byte gene = (byte) Math.round(Math.random());
            genes[i] = gene;
        }
        resultat();
    }
    
    public void resultat(){
        pourcen=0;
        for(i =9; i>=0;i--){
        	pourcen=pourcen+(genes[i]*(Math.pow(2,i)));
        }
        a=(int)(((pourcen/1023)*700)/10)+10;
        
        pourcen=0;
        for(i =genes.length-1; i>=10;i--){
        	pourcen=pourcen+(genes[i]*(Math.pow(2,(i-10))));
        }
        b=(int)(((pourcen/1023)*(80-a)))+10;
        
        c=(100-a-b);
    }

    public int getA() {
    	resultat();
		return a;
	}

	public int getB() {
		return b;
	}
	
	public int getC() {
		return c;
	}

	/* Getters and setters */
    // Use this if you want to create individuals with different gene lengths
    public static void setDefaultGeneLength(int length) {
        defaultGeneLength = length;
    }
    
    public byte getGene(int index) {
        return genes[index];
    }

    public void setGene(int index, byte value) {
        genes[index] = value;
        fitness = 0;
    }

    /* Public methods */
    public int size() {
        return genes.length;
    }

    public int getFitness() {
        if (fitness == 0) {
            fitness = FitnessCalc.getFitness(this);
        }
        return fitness;
    }

    @Override
    public String toString() {
        String geneString = "";
        for (int i = 0; i < size(); i++) {
            geneString += getGene(i);
        }
        return geneString;
    }
}