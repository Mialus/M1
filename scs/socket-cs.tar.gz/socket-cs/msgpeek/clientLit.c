/*
 **********************************************************
 *
 *  Programme : clientLit.c
 *
 *  ecrit par : LP.
 *
 *  resume :    invocation du serveur de gestion d'un buffer en lecture
 *                   avec MSG_PEEK
 *
 *  date :      15 / 01 / 10
 *
 ***********************************************************
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "fonctionsSocket.h"
#include "protocole.h"

main(int argc, char **argv) {
  int tailleLue;
  int sock,               /* descripteur de la socket locale */
      err, i;             /* code d'erreur */

  TypLectReq lrq;
  TypLectRep lrp;

  char boucle = 'o';


  /*
   * verification des arguments
   */
  if (argc != 2) {
    printf("usage : client nom_machine\n");
    exit(1);
  }

  do {
    /* 
     * creation d'une socket
     */
    printf("client : connect to %s, %d\n", argv[1], SERV_PORT);
    sock = socketClient(argv[1], SERV_PORT);
    if (sock < 0) {      
      printf("client : erreur socketClient\n");
      exit(2);
    }
 
    /* 
     * saisie de la taille
     */
    printf("clientLit : donner une taille : ");
    scanf("%d", &tailleLue);
    
    /*
     * composition de la requete
     */
    lrq.codeReq = LECT;
    
    if (tailleLue > TAIL_DATA) 
      lrq.tailLect = TAIL_DATA;
    else 
      lrq.tailLect = tailleLue;

    /*
     * envoi de la requete
     */
    err = send(sock, &lrq, sizeof(lrq), 0);
    if (err != sizeof(lrq)) {
      perror("clientLit : erreur sur le send");
      shutdown(sock, 2); close(sock);
      exit(3);
    }

    /*
     * reception de la reponse
     */ 
    err = recv(sock, &lrp, sizeof(lrp), 0);
    if (err == -1) {
      perror("clientLit : erreur a la reception");
      shutdown(sock, 2); close(sock);
      exit(4);
    }
    
    if (lrp.codeErr != ERR_OK) 
      printf("clientLit : erreur %d\n", lrp.codeErr);
    else {       
      printf("clientLit : taille lue %d\n", lrp.tailLue);
      printf("clientLit : message recu \n");
      for (i = 0; i < lrp.tailLue; i++)
	printf("%c ", lrp.donneesLu[i]);
      printf("\n");
    }
   
    /*
     * on continue ?
     */
    printf("client : on continue = o : ");
    
    // attention, l'espace avant le %c permet de vider le buffer 
    // du caractere CR (enter) de la saisie precedente
    scanf(" %c", &boucle);
    printf("\n");
  } while (boucle == 'o');
  
  /* 
   * fermeture de la connexion et de la socket 
   */
  shutdown(sock, 2);
  close(sock);
}
 

