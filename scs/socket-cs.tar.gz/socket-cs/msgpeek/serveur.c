/*
 **********************************************************
 *
 *  Programme : serveur.c
 *
 *  ecrit par : LP.
 *
 *  resume :    serveur de gestion de buffer
 *                 avec MSG_PEEK
 *
 *  date :      15 / 01 / 10
 *
 ***********************************************************
 */

#include <string.h>
#include <stdlib.h>

#include "fonctionsSocket.h"
#include "protocole.h"

/* donnees necessaires a la gestion du buffer */
#define TAIL_BUF 50
char buffer[TAIL_BUF];
int positionLect = 0;
int positionEcri = 0;
int plein = 0;

/*
 * fonction de reception et de traitement d'une requete de lecture
 */
void traitLectReq(int sock) {
  int i, err; 
  TypLectReq lectReq; 
  TypLectRep lectRep;

  err = recv(sock, &lectReq, sizeof(lectReq), 0);
  if (err < 0) {
    perror("serveur : traitLecReq, erreur dans la reception requete");
    shutdown(sock, 2);
    exit(5);
  }
  
  if (positionLect == positionEcri && plein == 0)
    // plus de donnees a lire
    lectRep.codeErr = ERR_BUF_VIDE;
  else { // recopie 
    i = 0;
    plein = 0; // reinit du booleen

    do {
      lectRep.donneesLu[i] = buffer[positionLect];
      positionLect = (positionLect + 1) % TAIL_BUF;
      i++;
    } while (positionLect != positionEcri && i != lectReq.tailLect) ;

    lectRep.tailLue = i;
    lectRep.codeErr = ERR_OK;
  }
  
  err = send(sock, &lectRep , sizeof(lectRep), 0);
  if (err != sizeof(lectRep)) {
    perror("serveur : traitLecReq, erreur dans l'envoi");
    shutdown(sock, 2);
    exit(5);
  }
}

/*
 * fonction de reception et de traitement d'une requete d'ecriture
 */
void traitEcriReq(int sock) {
  int i, err; 
  TypEcriReq ecriReq; 
  TypEcriRep ecriRep;

  err = recv(sock, &ecriReq, sizeof(ecriReq), 0);
  if (err < 0) {
    perror("serveur : traitEcriReq, erreur dans la reception requete");
    shutdown(sock, 2);
    exit(5);
  }
  
  if (positionLect == positionEcri && plein == 1)
    // plus de place pour ecrire    
    ecriRep.codeErr = ERR_BUF_PLEIN;
  else { // recopie 
    i = 0;
    while (plein != 1 && i != ecriReq.tailEcri) {
      buffer[positionEcri] = ecriReq.donneesEcri[i];
      positionEcri = (positionEcri+1) % TAIL_BUF;
      i++;

      if (positionLect == positionEcri) plein = 1; // buffer rempli
    }
    ecriRep.tailEcri = i;
    ecriRep.codeErr = ERR_OK;
  }
  
  err = send(sock, &ecriRep , sizeof(ecriRep), 0);
  if (err != sizeof(ecriRep)) {
    perror("serveur : traitLecReq, erreur dans l'envoi");
    shutdown(sock, 2);
    exit(5);
  }
}


/*
 * fonction main
 */
main(int argc, char** argv) {
  int sockCont, 
      sockTrans,	 /* descripteurs des sockets locales */
      err;  	         /* code d'erreur */
  TypCodReq       codeReq;      /* code de la requete recue */
  
  int             encore;       /* test de boucle pour les envois */
  
  int             taille;       /* taille de la chaine recue */
  
  /* 
   * creation de la socket
   */
  sockCont = socketServeur(SERV_PORT);
  if (sockCont < 0) {
    perror("serveur : erreur socketServeur");
    exit(2);
  }
  
  /*
   * boucle du serveur
   */
  for (;;) {
    /*
     * attente de connexion
     */
    sockTrans = accept(sockCont, NULL, NULL);
    if (sockTrans < 0) {
      perror("serveur :  erreur sur accept");
      close(sockCont);
      exit(3);
    }
    
    /*
     * reception du code de requete, maintenu dans la socket
     */
    err = recv(sockTrans, &codeReq, sizeof(codeReq), MSG_PEEK);
    if (err < 0) {
      perror("serveur : erreur dans la reception");
      shutdown(sockTrans, 2); close(sockTrans);
      close(sockCont);
      exit(4);
    }
    if (err == 0) {
      printf("Fin de la connexion \n");
      encore = 0;
    } else {
      /*
       * reception en fonction du code
       */
      switch(codeReq) {
      case LECT : 
	traitLectReq(sockTrans);
	break;
	
      case ECRI :
	traitEcriReq(sockTrans);
	break;
	
      default :
	printf("serveur : mauvais type de requete \n");
	// flush the false data
	char buf[100];
	err = recv(sockTrans, buf, 100, 0);
	
	TypLectRep lRep;
	lRep.codeErr = ERR_CODE_REQ;
	err = send(sockTrans, &lRep, sizeof(lRep), 0);
      }
    }
  }   
  /* 
   * arret de la connexion et fermeture
   */
  shutdown(sockTrans, 2); close(sockTrans);
  close(sockCont); 
}
