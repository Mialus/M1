/*
 **********************************************************
 *
 *  Programme : clientEcri.c
 *
 *  ecrit par : LP.
 *
 *  resume :    invocation du serveur de gestion d'un buffer en ecriture
 *                   avec une union des requetes
 *
 *  date :      15 / 01 / 10
 *
 ***********************************************************
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "fonctionsSocket.h"
#include "protocole.h"

main(int argc, char **argv) {
  char chaine[100];
  int sock,               /* descripteur de la socket locale */
      err;                /* code d'erreur */
  char boucle = 'o';
  int tailleChaine;


  /*
   * verification des arguments
   */
  if (argc != 2) {
    printf("usage : client nom_machine\n");
    exit(1);
  }

  do {
    /* 
     * creation d'une socket
     */
    printf("client : connect to %s, %d\n", argv[1], SERV_PORT);
    sock = socketClient(argv[1], SERV_PORT);
    if (sock < 0) {
      printf("client : erreur socketClient\n");
      exit(2);
    }
 
    /* 
     * saisie de la chaine 
     */
    printf("client : donner une chaine : ");
    scanf("%s", chaine);
    printf("client : envoi de - %s - \n", chaine);
    
    /*
     * composition de la requete
     */
    TypRequest rq;
    TypEcriRep erp;

    rq.codeReq = ECRI;

    if (strlen(chaine) > TAIL_DATA)
      rq.params.er.tailEcri = TAIL_DATA;
    else
      rq.params.er.tailEcri = strlen(chaine);
    
    memcpy(rq.params.er.donneesEcri, chaine, rq.params.er.tailEcri);

    /*
     * envoi de la requete
     */
    err = send(sock, &rq, sizeof(rq), 0);
    if (err != sizeof(rq)) {
      perror("client : erreur sur le send");
      shutdown(sock, 2); close(sock);
      exit(3);
    }

    /*
     * reception de la taille
     */ 
    err = recv(sock, &erp, sizeof(erp), 0);
    if (err == -1) {
      perror("client : erreur a la reception");
      shutdown(sock, 2); close(sock);
      exit(4);
    }
    if (erp.codeErr != ERR_OK) 
      printf("clientEcri : erreur %d\n", erp.codeErr);
    else   
      printf("clientEcri : taille ecri %d\n", erp.tailEcri);
   
    /*
     * on continue ?
     */
    printf("client : on continue = o : ");
    
    // attention, l'espace avant le %c permet de vider le buffer 
    // du caractere CR (enter) de la saisie precedente
    scanf(" %c", &boucle);
    printf("\n");
  } while (boucle == 'o');

  /* 
   * fermeture de la connexion et de la socket 
   */
  shutdown(sock, 2);
  close(sock);
}
 

