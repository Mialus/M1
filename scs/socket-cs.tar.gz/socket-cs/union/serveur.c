/*
 **********************************************************
 *
 *  Programme : serveur.c
 *
 *  ecrit par : LP.
 *
 *  resume :    serveur de gestion d'un buffer - 
 *                   avec une union des requetes
 *
 *  date :      15 / 01 / 10
 *
 ***********************************************************
 */

#include <string.h>
#include <stdlib.h>

#include "fonctionsSocket.h"
#include "protocole.h"

/* donnees liees à la gestion du buffer */
#define TAIL_BUF 50

char buffer[50];
int positionLect = 0;
int positionEcri = 0;
int plein = 0;

/*
 * fonction de reception et de traitement d'une requete de lecture
 */
void traitLectReq(TypLectReq lectReq, TypLectRep* lectRep) {
  int i;
  if (positionLect == positionEcri && plein == 0)
    // plus de donnees a lire
    lectRep->codeErr = ERR_BUF_VIDE;
  else { // recopie   
    i = 0;
    plein = 0; // reinit du booleen

    do {
      lectRep->donneesLu[i] = buffer[positionLect];
      positionLect = (positionLect + 1) % TAIL_BUF;
      i++;
    } while (positionLect != positionEcri && i != lectReq.tailLect);

    lectRep->tailLue = i;
    lectRep->codeErr = ERR_OK;
  }
}


/*
 * fonction de reception et de traitement d'une requete d'ecriture
 */
void traitEcriReq(TypEcriReq ecriReq, TypEcriRep* ecriRep) {
  int i;

  if (positionLect == positionEcri && plein == 1)
    // plus de place pour ecrire
    ecriRep->codeErr = ERR_BUF_PLEIN;
  else { // recopie   
    i = 0;
    while (plein != 1 && i != ecriReq.tailEcri) {
      buffer[positionEcri] = ecriReq.donneesEcri[i];
      positionEcri = (positionEcri + 1) % TAIL_BUF;
      i++;
      if (positionLect == positionEcri) plein = 1; // buffer rempli
    }

    ecriRep->tailEcri = i;
    ecriRep->codeErr = ERR_OK;
  }
}


/*
 * fonction main
 */
main(int argc, char** argv) {
  int sockCont, 
      sockTrans,       /* descripteurs des sockets locales */
      err;	        /* code d'erreur */
  TypRequest      req;           /* requete recue */
  
  TypLectRep      lectRep;
  TypEcriRep      ecriRep;      /* definition des structures de communication */      
  
  int             encore;       /* test de boucle pour les envois */
  
  int             taille;       /* taille de la chaine recue */
  
  /* 
   * creation de la socket
   */
  sockCont = socketServeur(SERV_PORT);
  if (sockCont < 0) {
    perror("serveur : erreur socketServeur");
    exit(2);
  }
  
  /*
   * boucle du serveur
   */
  for (;;) {
    /*
     * attente de connexion
     */
    sockTrans = accept(sockCont, NULL, NULL);
    if (sockTrans < 0) {
      perror("serveur :  erreur sur accept");
      close(sockCont);
      exit(3);
    }
    
    /*
     * reception du code de requete
     */
    err = recv(sockTrans, &req, sizeof(req), 0);
    if (err < 0) {
      perror("serveur : erreur dans la reception");
      shutdown(sockTrans, 2); close(sockTrans);
      close(sockCont);
      exit(4);
    }
    if (err == 0) {
      printf("Fin de la connexion \n");
      encore = 0;
    } else {
      /*
       * reception de la requete
       */
      switch(req.codeReq) {
      case LECT : 
	traitLectReq(req.params.lr, &lectRep);
	/* envoi de la reponse */
	err = send(sockTrans, &lectRep, sizeof(lectRep), 0);
	if (err != sizeof(lectRep)) {
	  perror("serveur : traitLecReq, erreur dans l'envoi");
	  shutdown(sockTrans, 2); close(sockTrans);
	  close(sockCont);
	  exit(5);
	}
	break;
	
      case ECRI :
	traitEcriReq(req.params.er, &ecriRep);
	/* envoi de la reponse */
	err = send(sockTrans, &ecriRep, sizeof(ecriRep), 0);
	if (err != sizeof(ecriRep)) {
	  perror("serveur : traitLecReq, erreur dans l'envoi");
	  shutdown(sockTrans, 2); close(sockTrans);
	  close(sockCont);
	  exit(5);
	}
	break;
	
      default :
	printf("serveur : mauvais type de requete \n");
	// flush the false data
	char buf[100];
	err = recv(sockTrans, buf, 100, 0);
	TypLectRep lRep;
	lRep.codeErr = ERR_CODE_REQ;
	err = send(sockTrans, &lRep, sizeof(lRep), 0);
      }
    }
  }   
  /* 
   * arret de la connexion et fermeture
   */
  shutdown(sockTrans, 2);  close(sockTrans);
  close(sockCont);
}
