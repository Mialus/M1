/*
 **********************************************************
 *
 *  Entete : protocole.h
 *
 *  ecrit par : LP.
 *
 *  resume :    donne les structures des donn�es utilis�es par
 *              le service buffer, avec une union des requetes
 *
 *              ATTENTION, on ne met dans ce fichier que ce qui
 *                         concerne la communication
 *
 *  date :      15 / 01 / 10
 *
 ***********************************************************
 */

#include "fonctionsSocket.h"

// --------------------------------------------
//
// constantes specifiques au protocole
//
// --------------------------------------------

#define SERV_PORT 6767
#define TAIL_DATA  20


// --------------------------------------------
//
// types enumeres : request type and error type
//
// --------------------------------------------

// codes des requetes
typedef enum { LECT, ECRI } TypCodReq;

// codes d'erreur
typedef enum {ERR_OK, 
	      ERR_BUF_PLEIN, 
	      ERR_BUF_VIDE, 
	      ERR_CODE_REQ 
} TypErr;

//------------------------
//
// structures Requetes / Reponses
//
//------------------------

// requete de lecture
typedef struct {
  int tailLect;
} TypLectReq;

// requete d'ecriture
typedef struct {
  int tailEcri;
  char donneesEcri[TAIL_DATA];
} TypEcriReq;

// union des requetes
typedef struct {
  TypCodReq codeReq;
  union {
    TypLectReq lr;
    TypEcriReq er;
  } params;
} TypRequest;

// reponse de lecture
typedef struct {
  TypErr codeErr;
  int tailLue;
  char donneesLu[TAIL_DATA];
} TypLectRep;

// reponse d'ecriture
typedef struct {
  TypErr codeErr;
  int tailEcri;
} TypEcriRep;

