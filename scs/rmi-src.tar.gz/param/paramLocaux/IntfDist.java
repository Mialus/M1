package param;
import java.rmi.Remote; 
import java.rmi.RemoteException;

public interface IntfDist extends Remote {
    
    public void passe(MonObjet objLoc) throws RemoteException;

    public MonObjet donne() throws RemoteException;
  
}

