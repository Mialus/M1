package param;

public class MonObjet implements java.io.Serializable {
    private int val;  
    public MonObjet(int val){
	this.val = val;
    }
    public void setVal(int val) {
	this.val = val;
    }
    public int getVal(){
	return val;
    }
}
