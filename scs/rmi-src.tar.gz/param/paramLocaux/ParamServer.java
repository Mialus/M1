package param;
import java.rmi.RemoteException;
import java.rmi.Naming;
import java.net.MalformedURLException;

public class ParamServer {
    public static void main(String [] args) {
	
	try {	    
	    IntfDistImpl objDist = new IntfDistImpl();
	    
	    try{	
		Naming.rebind("objDist", objDist);
	    }
	    // Necessaire pour utiliser le Naming
	    catch(MalformedURLException e) {
		System.out.println(e); 
	    }
	    System.out.println("Serveur pret"); 
	} catch (RemoteException re) {
	    System.out.println(re); 
	}

    }
}



