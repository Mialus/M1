package param;
import java.rmi.RemoteException ;
import java.rmi.server.UnicastRemoteObject;
import java.net.MalformedURLException;

public class IntfDistImpl
    extends UnicastRemoteObject
    implements IntfDist {

    public IntfDistImpl() throws RemoteException {
	super();
    }

    // toutes les methodes rmi doivent lever Remote Exception
    public void passe(MonObjet objLoc)throws RemoteException {
	objLoc.setVal(30);
	System.out.println("Chez le serveur : Val = " + objLoc.getVal());
    }

    public MonObjet donne() throws RemoteException {
	MonObjet objLoc = new MonObjet(30);
	System.out.println("Chez le serveur : Val = " + objLoc.getVal());
	return objLoc;
    }
} 

