package param;

import java.rmi.Naming;
import java.rmi.RemoteException ; 
import java.rmi.NotBoundException;

public class ParamClient {
    public static void main(String [] args) {
	if (args.length != 1){
	   System.out.println("parametre - machine:port");
           System.exit(1);
        }
	MonObjet o = new MonObjet(10);
	try {
	    IntfDist objDist =(IntfDist) Naming.lookup("//"+ args[0]+"/objDist");
	    objDist.passe(o);
	    System.out.println("Chez le client : Val = " + o.getVal());
	    o.setVal(20);
	    System.out.println("Chez le client après modif : Val = " + o.getVal());

	    System.out.println("Valeur d'objet local retournée:");
	    MonObjet o1 = objDist.donne();
	    System.out.println("Chez le client : Val = " + o1.getVal());
	    o1.setVal(45);
	    System.out.println("Chez le client après modif : Val = " + o1.getVal());

	} catch (RemoteException e) {
	    System.out.println(e); 
	} catch (NotBoundException e) {
	    System.out.println(e);
	} catch (java.net.MalformedURLException e) {    
	    System.out.println(e);
	}
    }
}
