package paramD;
import java.rmi.RemoteException ;
import java.rmi.server.UnicastRemoteObject ;
import java.net.MalformedURLException ;

public class IntfDistImpl
    extends UnicastRemoteObject
    implements IntfDist {

    private ObjetIntf o;
    // constructeur remontant l'exception RemoteException
    public IntfDistImpl() throws RemoteException {
	super();
	o = new ObjetImpl();
	o.setVal(20);
    }

    public ObjetIntf getRefObj() throws RemoteException{
	return o;
    }
} 

