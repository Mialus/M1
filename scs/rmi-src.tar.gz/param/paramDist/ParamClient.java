package paramD;

import java.rmi.Naming;
import java.rmi.RemoteException ; 
import java.rmi.NotBoundException;

public class ParamClient {
    public static void main(String [] args) {
	if (args.length != 1){
	   System.out.println("parametre - machine:port");
           System.exit(1);
        }
	try {
	    IntfDist objDist = (IntfDist)Naming.lookup("//"+ args[0]+"/objDist");
	    ObjetIntf i = objDist.getRefObj();
	    int value = i.getVal();
	    System.out.println("Chez le client : Val = " + value);
	    i.setVal(40);
	    System.out.println("Chez le serveur après modif : Val = " + objDist.getRefObj().getVal());
	} catch (RemoteException e) {
	    System.out.println(e) ; 
	} catch (NotBoundException e) {  
	    System.out.println(e);
	} catch (java.net.MalformedURLException e) {
	    System.out.println(e);
	}
    }
}
