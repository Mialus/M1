package paramD;

import java.rmi.Remote;
import java.rmi.RemoteException;
public interface ObjetIntf extends Remote {
	public int getVal() throws RemoteException;
	public void setVal(int v) throws RemoteException;    
}
