package paramD;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class ObjetImpl extends UnicastRemoteObject
		       implements ObjetIntf  {
	private int val;
	public ObjetImpl() throws RemoteException {
		super();
        }
	public int getVal() throws RemoteException {
		return val;
	}
	public void setVal(int v) throws RemoteException {
		this.val = v;
	}
}
