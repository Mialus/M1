package paramD;
import java.rmi.Remote ; 
import java.rmi.RemoteException;

public interface IntfDist extends Remote {
    
    public ObjetIntf getRefObj() throws RemoteException;
  
}

