package exhelloLoc;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.NotBoundException; 

public class HelloClient {
    
    public static void main(String [] args) {
	if (args.length != 1) {
	   System.out.println("parametre - machine:port");
	   System.exit(1);
	}
	try {
	    
	    // recherche de la reference de l'objet distant a partir de 
	    // son nom dans le serveur de noms
	    HelloIntf objHello = (HelloIntf) Naming.lookup("//"+args[0]+"/ObjHelloRemote");
	    
	    // invocation de methodes de l'objet distant
	    objHello.hello(); 
	}
	// gestion des exceptions lookup et invocation
	catch (RemoteException e) {
	    System.out.println("Erreur de communcication " + e); 
	} catch (NotBoundException e) {  
	    System.out.println("Erreur : l'objet distant n'est pas enregistre " + e);
	} catch (java.net.MalformedURLException e) {
	    System.out.println("Erreur : l'URL est incorrecte " + e);
	}
    }
}
