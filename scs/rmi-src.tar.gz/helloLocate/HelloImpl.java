package exhelloLoc;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class HelloImpl extends UnicastRemoteObject
    implements HelloIntf {

    // il faut pouvoir remonter l'exception RemoteException
    public HelloImpl()	throws RemoteException {
	// appel à super() implicite 	
	//super();
    }

    // toutes les methodes distantes doivent lever Remote Exception
    public void hello()	throws RemoteException {
	System.out.println("Hello world");
    }
   
}



