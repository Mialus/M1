package exhelloLoc;
import java.rmi.RemoteException;
import java.rmi.Naming;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.net.MalformedURLException;

public class HelloServer {
    private static int PORT = 1099;
    public static void main(String [] args) {
	System.out.println("bonjour");
	try {
	    // creation d'un objet distant
	    HelloImpl objServHello = new HelloImpl();

	    try{
		// creation dynamique de rmiregistry
		Registry myRegistry = LocateRegistry.createRegistry(PORT);
		// publication de l'objet distant dans le serveur
		// de noms
		Naming.rebind("ObjHelloRemote", objServHello);
	    }
	    // necessaire pour utiliser le Naming
	    catch(MalformedURLException e) {
		System.out.println("Exception Naming " + e); 
	    }
	    System.out.println("Serveur pret"); 
	} catch (RemoteException re) {
	    System.out.println("Exception Remote " + re); 
	}
    }
}



