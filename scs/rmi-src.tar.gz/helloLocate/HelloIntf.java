
package exhelloLoc;

import java.rmi.Remote;
import java.rmi.RemoteException; 

// les interfaces distantes heritent de Remote
public interface HelloIntf extends Remote {
    
    // toutes les methodes distantes peuvent generer une RemoteException
    public void hello()
	throws RemoteException;

}
