package exhello;
import java.rmi.RemoteException;
import java.rmi.Naming;
import java.net.MalformedURLException;
import java.rmi.RMISecurityManager;

public class HelloServer {
    
    public static void main(String [] args) {
	//System.setSecurityManager(new RMISecurityManager());
	
	try {
	    // creation d'un objet serveur
	    HelloImpl objServHello = new HelloImpl();

	    try{
		// publication de l'objet distant dans le serveur de noms
		// rmiregistry
		Naming.rebind("ObjHelloRemote", objServHello);
	    }
	    // necessaire pour utiliser le Naming
	    catch(MalformedURLException e) {
		System.out.println("Exception Naming " + e); 
	    }
	    System.out.println("Serveur pret"); 
	} catch (RemoteException re) {
	    System.out.println("Exception Remote " + re); 
	}
    }
}



