package exhello;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class HelloImpl extends UnicastRemoteObject
    implements HelloIntf {
    
    // ceci est indispensable pour 
    // les objets distants, il faut pouvoir remonter l'exception
    public HelloImpl() throws RemoteException {
	// appel à super() implicite 	
	//super();
    }

    // toutes les methodes rmi doivent lever RemoteException
    public void hello()	throws RemoteException {
	System.out.println("Hello world");
    }
    
}



