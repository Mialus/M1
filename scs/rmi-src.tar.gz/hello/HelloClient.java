package exhello;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.NotBoundException; 
import java.rmi.RMISecurityManager;

public class HelloClient {
    
    public static void main(String [] args) {
	if (args.length != 1) {
	   System.out.println("parametre - machine:port");
	   System.exit(1);
	}
	//System.setSecurityManager(new RMISecurityManager());
	
	try {	    
	    // recherche de la reference de l'objet distant a partir de 
	    // son nom dans le serveur de noms
	    HelloIntf objHello =(HelloIntf) Naming.lookup("//"+args[0]+"/ObjHelloRemote");
	    
	    // invocation des methodes de l'objet distant
	    objHello.hello() ; 
	}
	// gestion des exceptions lookup et invocation
	 catch (RemoteException e) {
	    System.out.println("Erreur de communication " + e) ; 
	}catch (java.net.MalformedURLException e) {
	    System.out.println("Erreur : l'URL est incorrecte " + e );
	} catch (NotBoundException e) {
	    System.out.println("Erreur : l'objet n'est pas enregistre " + e);
	}
	
    }
}
