//
// Prgm: exercice serveur de messages
//
// auteur : VF
//
// date : 20/ 09/ 11
//

import java.net.Socket;
import java.net.UnknownHostException;
import java.io.ObjectInputStream;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class Client {
    public static final String HOTE = "localhost";
    public static final int PORT = 5555;
    
    public static void main(String [] args) {

	Socket s ;

	// references de la socket
	String hote = HOTE ;
	int port = PORT;
	
	try {
	    s = new Socket (hote, port) ;

	    // streams et ObjectStreams pour l'acces aux sockets
	    OutputStream os = s.getOutputStream();
	    ObjectOutputStream oos = new ObjectOutputStream(os);

	    InputStream is = s.getInputStream();
	    ObjectInputStream ois = new ObjectInputStream(is);

	    // envoi/reception des messages
	    
	    // envoi
	    oos.writeObject("aaa");
	    // retour 
	    String rep1 = (String) (ois.readObject());
	    System.out.println("J'ai recu : " + rep1);
	    // envoi
	    oos.writeObject("bbb");
	    // retour 
	    String rep2 = (String) (ois.readObject());
	    System.out.println("J'ai recu : " + rep2);

	    // envoi fin client
	    oos.writeObject("FIN");

	    ois.close();
	    oos.close();
	    os.close();
	    is.close();
	    s.close();
	} catch (UnknownHostException e) { 
	    System.out.println("Unknown host" + e);
	} catch (Exception e) {   
	    System.out.println("IO exception" + e);
	}
	
    }
    
}
