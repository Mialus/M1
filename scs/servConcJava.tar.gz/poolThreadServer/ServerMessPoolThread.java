//
// Prgm: exercice serveur de messages
//       pool de threads
//
// auteur : VF
//
// date : 20/ 09/ 11
//

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

class TraitReq extends Thread {
    ServerSocket srv;

    public TraitReq(ServerSocket sock) {
	srv = sock;
    }    

    public void run() {		
	Socket s; 
	while(true) {
	    try {
	  	boolean fini = false;

		// nouvelle connexion
		s = srv.accept() ;
		System.out.println("New request for thread " + this.getName());
		
		// obtient les streams en out et in
		OutputStream os =  s.getOutputStream();
		InputStream is = s.getInputStream();
		
		// et les gestionnaire d'objets correspondants
		ObjectInputStream ois = new ObjectInputStream(is);
		ObjectOutputStream oos = new ObjectOutputStream(os);
		
		// recoit les requetes
		while (!fini) {
		    Thread.sleep(1000);
		    
		    // recoit une requete
		    String recu = (String)ois.readObject();
		    if (recu.equals("FIN")) {
			System.out.println("fin");
			fini = true;	
		    } else 
			oos.writeObject("Echo " + recu);			
		}
		// end of client connexion
		// close streams and socket
		oos.close();
		ois.close();
		is.close();
		os.close();
		s.close();
	    } catch (InterruptedException ie) {
	      System.out.println("Run: InterruptedException " + ie);
   	    } catch (IOException ioe) {
  	      System.out.println("Run: IoException " + ioe);
  	    } catch(ClassNotFoundException cnfe) { 
	      System.out.println("run ClassNotFoundException " + cnfe);
	    }
        }
    }

}

public class ServerMessPoolThread {
 
    public static final int PORT = 5555;
   
    // taille du pool de threads
    private static final int NBTHR = 3;

    public static void main(String [] args) {
	
	// definitions pour les sockets
	ServerSocket srv;
	int port = PORT ;
	
	try {

	    srv = new ServerSocket(port);

	    // thread pool creation 
	    TraitReq[] threadTab = new TraitReq[NBTHR];
	    for (int i = 0; i < NBTHR; i++) {
		threadTab[i] = new TraitReq(srv);
		threadTab[i].start();
	    }

	    // do nothing or receive request as the child threads
	    // threadTab[ 0 ].join();

	    // Should never been reached

	} catch(IOException e) { 
	    System.out.println("IO exception" + e);
	} /*catch(InterruptedException ie) { 
	    System.out.println("InterruptedException" + ie);
	} */
    }
}
