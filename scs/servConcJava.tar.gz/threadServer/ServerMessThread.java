//
// Prgm: exercice serveur de messages
//       serveur multi-threadé
//
// auteur : VF
//
// date : 20/ 09/ 11
//

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

class TraitReq extends Thread {
    private Socket s;

    public TraitReq(Socket sock) {
	s = sock;
    }    

    public void run() {	
	boolean fini = false;
	try {
	  // obtient les streams en out et in
	  OutputStream os =  s.getOutputStream();
	  InputStream is = s.getInputStream();	
     	
 	  // et les gestionnaire d'objets correspondants
	  ObjectInputStream ois = new ObjectInputStream(is);
	  ObjectOutputStream oos = new ObjectOutputStream(os);
		
  	  // recoit les requetes
   	  while (!fini) {
		    
		Thread.sleep(1000);
		    
		// recoit une requete
		String recu = (String)ois.readObject();
		if (recu.equals("FIN")) {	
			System.out.println("fin");
			fini = true;	
		} else 
			oos.writeObject("Echo " + recu);			
	   }
	   // End of client connexion
	   // Close streams and socket
	   oos.close();
	   ois.close();
	   is.close();
	   os.close();
	   s.close();
	} catch (InterruptedException ie) {
	    System.out.println("Run: InterruptedException " + ie);
	} catch (IOException ioe) {
	    System.out.println("Run: IoException " + ioe);
	} catch(ClassNotFoundException cnfe) { 
	    System.out.println("run ClassNotFoundException " + cnfe);
	}
    }

}

public class ServerMessThread {
    public static final int PORT = 5555;
    public static void main(String [] args) {
	
	// definitions pour les sockets
	ServerSocket srv;
	int port = PORT ;
	Socket s = null;

	try {
	    srv = new ServerSocket(port);
	    while (true) { 
		s = srv.accept() ;
		TraitReq tr = new TraitReq(s);
		tr.start();
	    } 
	    // should never been reached
	} catch(IOException e) { 
	    System.out.println("IO exception" + e);
	}
    }
}
