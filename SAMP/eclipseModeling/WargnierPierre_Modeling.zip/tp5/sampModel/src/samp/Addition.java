/**
 */
package samp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Addition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see samp.SampPackage#getAddition()
 * @model
 * @generated
 */
public interface Addition extends OperationBinaire {
} // Addition
