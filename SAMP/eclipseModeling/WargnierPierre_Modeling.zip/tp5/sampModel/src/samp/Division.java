/**
 */
package samp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Division</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see samp.SampPackage#getDivision()
 * @model
 * @generated
 */
public interface Division extends OperationBinaire {
} // Division
