/**
 */
package samp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Multiplication</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see samp.SampPackage#getMultiplication()
 * @model
 * @generated
 */
public interface Multiplication extends OperationBinaire {
} // Multiplication
