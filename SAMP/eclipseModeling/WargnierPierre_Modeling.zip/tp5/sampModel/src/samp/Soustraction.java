/**
 */
package samp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Soustraction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see samp.SampPackage#getSoustraction()
 * @model
 * @generated
 */
public interface Soustraction extends OperationBinaire {
} // Soustraction
