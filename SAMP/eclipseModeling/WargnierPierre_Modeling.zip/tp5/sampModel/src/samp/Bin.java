/**
 */
package samp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bin</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see samp.SampPackage#getBin()
 * @model
 * @generated
 */
public interface Bin extends OperationUnaire {
} // Bin
