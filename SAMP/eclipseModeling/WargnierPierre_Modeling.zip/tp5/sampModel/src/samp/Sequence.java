/**
 */
package samp;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sequence</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see samp.SampPackage#getSequence()
 * @model abstract="true"
 * @generated
 */
public interface Sequence extends EObject {
} // Sequence
