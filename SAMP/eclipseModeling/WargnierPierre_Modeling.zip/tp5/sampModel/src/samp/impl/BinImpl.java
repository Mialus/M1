/**
 */
package samp.impl;

import org.eclipse.emf.ecore.EClass;

import samp.Bin;
import samp.SampPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bin</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BinImpl extends OperationUnaireImpl implements Bin {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BinImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SampPackage.Literals.BIN;
	}

} //BinImpl
